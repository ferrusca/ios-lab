//
//  Pokemon.swift
//  pokedex
//
//  Created by Jorge Ferrusca on 21/06/24.
//

import Foundation

enum PokemonType: String, CaseIterable, Codable {
    case Normal = "Normal",
    Fire = "Fire",
    Water = "Water",
    Electric = "Electric",
    Grass = "Grass",
    Ice = "Ice",
    Fighting = "Fighting",
    Poison = "Poison",
    Ground = "Ground",
    Flying = "Flying",
    Psychic = "Psychic",
    Bug = "Bug",
    Rock = "Rock",
    Ghost = "Ghost",
    Dragon = "Dragon",
    Dark = "Dark",
    Steel = "Steel",
    Fairy = "Fairy"
}

struct Pokemon: Codable {
    let id: Int
    let name: String
    let number: String
//    let type: [PokemonType]
    let type: [String]
    let imageURL: String
    
    private enum CodingKeys: String, CodingKey {
        case id, name, type
        case number = "num"
        case imageURL = "img"
    }
}
