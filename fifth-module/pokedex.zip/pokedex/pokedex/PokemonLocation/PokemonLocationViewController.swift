//
//  PokemonLocationViewController.swift
//  pokedex
//
//  Created by Jorge Ferrusca on 21/06/24.
//

import UIKit
// Importing maps
import MapKit
// access to user location
import CoreLocation

class PokemonLocationViewController: UIViewController {
    
    // creating map view
    private lazy var mapView: MKMapView = {
        let mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        
        return mapView
    }()
    
    private let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        // ask for user permission
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        setupView()
    }
    
    // Setup map
    private func setupView() {
        view.backgroundColor = .systemBackground
        
        // adding map to main view
        view.addSubview(mapView)
        
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: view.topAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
        ])
    }
}

extension PokemonLocationViewController: CLLocationManagerDelegate {
    // runs every time the location is updated
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let lastLocation = locations.last else { return }
        
        let coordinate = CLLocationCoordinate2D(latitude: lastLocation.coordinate.latitude, 
                                                longitude: lastLocation.coordinate.longitude)
        
        // adding pin (aka annotation)
        let userAnnotation = MKPointAnnotation()
        userAnnotation.coordinate = coordinate
        
        mapView.addAnnotation(userAnnotation)
    }
}

// NOTE: Add to infoplist the location permission with a description "(Privacy - Location When In Use Usage Description)"
