//
//  ViewController.swift
//  pokedex
//
//  Created by Jorge Ferrusca on 21/06/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

