//
//  PokemonListViewModel.swift
//  pokedex
//
//  Created by Jorge Ferrusca on 21/06/24.
//

import Foundation

class PokemonListViewModel {
//  access modifiers: fileprivate, private, internal (default), public
    
    private let pokemonDataFileName = "pokemon_list"
    private let pokemonDataFileExtension = "json"
    private var pokemonList = [Pokemon]()
    
    let cellIdentifier = "pokemonCellIdentifier"
    var pokemonCount: Int { pokemonList.count }
    let title = "Pokédex"
    
    init() { 
        pokemonList = loadPokemonData()
    }
    
    private func loadPokemonData() -> [Pokemon] {
        guard let fileURL = Bundle.main.url(
            forResource: pokemonDataFileName,
            withExtension: pokemonDataFileExtension
        ),
              let data = try? Data(contentsOf: fileURL),
              let pokemonList = try? JSONDecoder().decode([Pokemon].self, from: data)
        else {
            // stops here when in dev mode. In production this error is not thrown
            assertionFailure("Cannot read file \"\(pokemonDataFileName)\"")
            return []
        }
        return pokemonList
    }
    
    func pokemon(at: IndexPath) -> Pokemon {
        return pokemonList[at.row]
    }
}
